# collegeweb
A Education website of Hindu Institute of Management, sonipat 

# website link 
output : 
https://ajeetkumar06.github.io/collegeweb/

